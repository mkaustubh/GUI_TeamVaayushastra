/**
 * User Interface (UI) widgets like a compass or a bar scale.
 * 
 * See {@link de.fhpotsdam.unfolding.examples.ui} for a ZoomSlider.
 */

package de.fhpotsdam.unfolding.ui;

