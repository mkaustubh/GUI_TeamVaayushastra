/**
  Helper functions and classes for Unfolding.
 */

package de.fhpotsdam.unfolding.utils;
